#!/usr/bin/env python

from __init__ import main

main()
