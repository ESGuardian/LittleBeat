// Require config
var app = require('ui/modules').get('app/wazuh', []);

app.controller('auditController', function ($scope, $q, DataFactory, errlog) {

}); 